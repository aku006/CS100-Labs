#ifndef __SCI_RAND__
#define __SCI_RAND__

#include <iostream>
#include <sstream>
#include "rand.hpp"

class SciRand : public Rand {
	public:
		SciRand() : Rand() {  }

		virtual std::string stringify() {
			std::ostringstream streamObj;

			streamObj << std::scientific;
			streamObj << this->evaluate();
			std::string strObj = streamObj.str();
			return strObj;
		}
};

#endif
