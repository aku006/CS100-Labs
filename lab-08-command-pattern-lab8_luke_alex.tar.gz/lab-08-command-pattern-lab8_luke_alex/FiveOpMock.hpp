#ifndef __FIVEOPMOCK_HPP__
#define __FIVEOPMOCK_HPP__

#include "base.hpp"
#include <iostream>
#include <string>

class FiveOpMock: public Base {
    public:
        FiveOpMock() { };

        virtual double evaluate() { return 5; }
        virtual std::string stringify() { return "5"; }
};

#endif
