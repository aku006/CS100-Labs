#ifndef __SUBTRACT_H__
#define __SUBTRACT_H__

#include "base.hpp"

class subtract : public Base {
        private:
                Base* leftOp;
                Base* rightOp;
        public:
                subtract(Base* l, Base* r) {
                        leftOp = l;
                        rightOp = r;
                }

                virtual double evaluate() {
                        return (leftOp->evaluate() - rightOp->evaluate());
                }

                virtual std::string stringify() {
                        return (leftOp->stringify() + " - " + rightOp->stringify());
                }
};

#endif

