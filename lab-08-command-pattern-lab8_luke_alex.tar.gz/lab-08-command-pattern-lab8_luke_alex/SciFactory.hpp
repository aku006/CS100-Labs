#ifndef __SCI_FACTORY_HPP__
#define __SCI_FACTORY_HPP__

#include "base_factory.hpp"
#include "SciOp.hpp"
#include "SciRand.hpp"

class SciFactory : public BaseFactory {
	public:
		SciFactory() : BaseFactory() {};

		op* createOp(double value) {
			SciOp* op = new SciOp(value);
			return op;
		}

		Rand* createRand() {
			SciRand* op = new SciRand();
			return op;
		}
};

#endif
