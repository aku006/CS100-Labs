#ifndef __SUB_COMMAND_HPP_
#define __SUB_COMMAND_HPP_

#include "base.hpp"
#include "command.hpp"
#include "op.hpp"
#include "rand.hpp"
#include "subtract.hpp"

class SubCommand : public Command {
	private:
		Command* cmd;
	public:
		SubCommand(Command* prev, Base* now) {
			cmd = prev;
			root = new subtract(cmd->get_root(), now);
		}

		~SubCommand() {
			delete root;
		}

		double execute() {
			return (root->evaluate());
		}

		std::string stringify() {
			return root->stringify();
		}
		
		Base* get_root() {
			return root;
		}
};

#endif
