#ifndef __POW_COMMAND_HPP__
#define __POW_COMMAND_HPP__

#include "base.hpp"
#include "command.hpp"
#include "op.hpp"
#include "rand.hpp"
#include "power.hpp"

class PowCommand : public Command {
	private:
		Command* cmd;
	public:
		PowCommand(Command* prev, Base* now) {
			cmd = prev;
			root = new power(cmd->get_root(), now);
		}

		~PowCommand() {
			delete root;
		}

		double execute() {
			return root->evaluate();
		}

		std::string stringify() {
			return root->stringify();
		}

		Base* get_root() {
			return root;
		}
};

#endif

