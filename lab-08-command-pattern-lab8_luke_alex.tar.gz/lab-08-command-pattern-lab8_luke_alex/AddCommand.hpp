#ifndef __ADD_COMMAND_HPP__
#define __ADD_COMMAND_HPP__

#include "op.hpp"
#include "rand.hpp"
#include "add.hpp"
#include "base.hpp"
#include "command.hpp"

class AddCommand : public Command {
	private:
		Command* cmd;
	public:
		AddCommand(Command* prev, Base* now) {
			cmd = prev;
			root = new add(cmd->get_root(), now);
		}

		~AddCommand() {
			delete root;
		}

		double execute() {
			return (root->evaluate());
		}

		std::string stringify() {
			return root->stringify();
		}

		Base* get_root() {
			return root;
		}
};

#endif
