#include "command.hpp"
#include "base.hpp"


class Menu {
	private:
		int history_index;
		std::vector<Command*> history;
	public:
		Menu() {
			history_index = 0;
			history.resize(0);
		}
		
		std::string execute() {
			return std::to_string(history.at(history_index)->execute());
		}

		std::string stringify() {
			return history.at(history_index)->stringify();
		}
		
		bool initialized () {
			//std::cout << "yeet2" << std::endl;
			if (history.size() >= 1) {
				return true;
			}
			return false;
			//std::cout << "yeet3" << std::endl;
		}
		
		void add_command(Command* cmd) {
			
			//std::cout << "yeet 1" << std::endl;
			if(history.size() == 0) {
				//std::cout << "yeet 2" << std::endl;
				history.push_back(cmd);
				//std::cout << "yeet 3" << std::endl;

			}
			else if(history_index < (history.size() - 1) ) {
			//std::cout << "yeet 1" << std::endl;
				for (int i = history.size() - 1; i > history_index; --i) {
					history.pop_back();
				}
				history.push_back(cmd);
				history_index++;
			} else {
				history.push_back(cmd);
				history_index++;
			}
			//history.push_back(cmd);
			//history_index = history_index + 1;
		}
		
		Command* get_command() {
			return history.at(history_index);
		}
		
		void undo() {
			if(history_index > 0) {
				history_index--;
			}
		}
	
		void redo() {
			if(history_index < history.size()-1 ) {
				history_index++;
			} 
		}
};
