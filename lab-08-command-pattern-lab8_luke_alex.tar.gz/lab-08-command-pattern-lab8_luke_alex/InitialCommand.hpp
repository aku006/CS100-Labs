#ifndef __INITIAL_COMMAND_HPP__
#define __INITIAL_COMMAND_HPP__

#include "base.hpp"
#include "op.hpp"
#include "rand.hpp"
#include "command.hpp"

class InitialCommand : public Command {
	public:
		InitialCommand(Base* yeetus) {
			root = yeetus;
		}
		
		~InitialCommand() {
			delete root;
		}

		double execute() {
			return root->evaluate();
		}

		std::string stringify() {
			return root->stringify();
		}

		Base* get_root() {
			return root;
		}
};

#endif
