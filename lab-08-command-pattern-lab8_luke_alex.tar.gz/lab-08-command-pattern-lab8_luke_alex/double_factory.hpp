#ifndef __DOUBLE_FACTORY_HPP__
#define __DOUBLE_FACTORY_HPP__

#include "base_factory.hpp"
#include "op.hpp"
#include "rand.hpp"

class DoubleFactory : public BaseFactory {
    public:
        /* Constructor */
        DoubleFactory() : BaseFactory() {};

        /*Production Function */
        op* createOp(double value) {
		op *op1 = new op(value); 
		return op1;
	}

        Rand* createRand() {
		Rand *op1 = new Rand();
		return op1;
	}
};


#endif //__PRECISION_FACTORY_HPP__
