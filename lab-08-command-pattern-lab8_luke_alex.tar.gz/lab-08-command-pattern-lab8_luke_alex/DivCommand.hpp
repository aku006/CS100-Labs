#ifndef __DIV_COMMAND_HPP__
#define __DIV_COMMAND_HPP__

#include "base.hpp"
#include "command.hpp"
#include "op.hpp"
#include "rand.hpp"
#include "Div.hpp"

class DivCommand : public Command {
	private:
		Command* cmd;
	public:
		DivCommand(Command* prev, Base* now) {
			cmd = prev;
			root = new Div(cmd->get_root(), now);
		}
	
		~DivCommand() {
			delete root;
		}

		double execute() {
			return root->evaluate();
		}

		std::string stringify() {
			return root->stringify();
		}

		Base* get_root() {
			return root;
		}
};

#endif

