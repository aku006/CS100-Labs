#ifndef __MULT_COMMAND_HPP__
#define __MULT_COMMAND_HPP__

#include "base.hpp"
#include "command.hpp"
#include "rand.hpp"
#include "op.hpp"
#include "multiply.hpp"

class MultCommand : public Command {
	private:
		Command* cmd;
	public:
		MultCommand(Command* prev, Base* now) {
			cmd = prev;
			root = new multiply(cmd->get_root(), now);
		}

		~MultCommand() {
			delete root;
		}

		double execute() {
			return root->evaluate();
		}

		std::string stringify() {
			return root->stringify();
		}

		Base* get_root() {
			return root;
		}
};

#endif
