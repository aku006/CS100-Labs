#include <iostream>

int count(const std::string& phrase) {
    return 0;
}

