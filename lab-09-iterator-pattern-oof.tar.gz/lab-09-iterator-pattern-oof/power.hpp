#ifndef __POWER_HPP__
#define __POWER_HPP__

#include <cmath>
#include "base.hpp"
#include "binary_iterator.hpp"

class power : public Base {
        private:
                Base *leftOp;
                Base *rightOp;
        public:
                power(Base *l, Base *r) {
                        leftOp = l;
                        rightOp = r;
                }

                virtual double evaluate() {
                        return pow(leftOp->evaluate(), rightOp->evaluate());
                }
                virtual std::string stringify() {
                        return leftOp->stringify() + " ** " + rightOp->stringify();
                }
		virtual Base* get_left() {
			return leftOp;
		}
		virtual Base* get_right() {
			return rightOp;
		}
		virtual Iterator* create_iterator() {
			BinaryIterator* powerIterator = new BinaryIterator(this);
			return powerIterator;
		}
};

#endif
