#ifndef __RAND_HPP__
#define __RAND_HPP__

#include <string>
#include <cstdlib>
#include "base.hpp"
#include "null_iterator.hpp"

class Rand : public Base {
	private:
		double x;
	public:
		/*constructors*/
		Rand() {
			srand(1);
			x = (double)(rand() % 100);
    }
		
		/*member functions*/
		virtual double evaluate() {
			return x;
		}

		virtual std::string stringify() {
			std::ostringstream obj;
			obj << std::fixed;
			obj << std::setprecision(6);
			obj << this->evaluate();
			std::string objConv = obj.str();
			return objConv;
		}

		virtual Base* get_left() {
			return nullptr;
		}
		virtual Base* get_right() {
			return nullptr;
		}
		virtual Iterator* create_iterator() {
			NullIterator* poop = new NullIterator(this);
			return poop;
		}
};

#endif //__RAND_HPP__

