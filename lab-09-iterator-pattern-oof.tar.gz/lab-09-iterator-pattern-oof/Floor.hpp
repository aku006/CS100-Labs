#ifndef __FLOOR_HPP__
#define __FLOOR_HPP__

#include <iostream>
#include <cmath>
#include "base.hpp"
#include "unary_iterator.hpp"

class Floor : public Base {
	private:
		Base* target;
	public:
		Floor(Base* t) {
			target = t;
		}

		virtual double evaluate() {
			return std::floor(target->evaluate());
		}
	
		virtual std::string stringify() {
			return target->stringify();
		}

		virtual Base* get_left() {
			return target;
		}

		virtual Base* get_right() {
			return nullptr;
		}
		virtual Iterator* create_iterator() {
			UnaryIterator* floorIterator = new UnaryIterator(this);
			return floorIterator;
		}
};



#endif
