#ifndef __ABS_HPP__
#define __ABS_HPP__

#include <iostream>
#include <cmath>
#include "base.hpp"
#include "unary_iterator.hpp"

class Abs : public Base {
	private:
		Base* target;
	public:
		Abs(Base* t) {
			target = t;
		}

		virtual double evaluate() {
			return std::abs(target->evaluate());
		}
	
		virtual std::string stringify() {
			return target->stringify();
		}
	
		virtual Base* get_left() {
			return target;
		}

		virtual Base* get_right() {
			return nullptr;
		}
		virtual Iterator* create_iterator() {
			UnaryIterator* absIterator = new UnaryIterator(this);
			return absIterator;
		}
};

#endif
