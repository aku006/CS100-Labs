#ifndef __UNARY_ITERATOR_HPP__
#define __UNARY_ITERATOR_HPP__

#include "iterator.hpp"

class UnaryIterator : public Iterator {
	protected:
		Base* curr;
	public:
		UnaryIterator(Base *ptr): Iterator(ptr) {}
		
		//sets up iterator to start at beginning of traversal
		void first() {
			curr = self_ptr->get_left();
		}
		
		//move onto next element
		void next() {
			curr = nullptr;
		}

		//returns if you finished iteratoring thru all elements
		bool is_done() {
			return true;
		}
		
		//return the element the iterator is currently at
		Base* current() {
			return curr;
		}
};

#endif
