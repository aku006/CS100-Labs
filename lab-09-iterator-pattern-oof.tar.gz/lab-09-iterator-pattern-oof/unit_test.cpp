#include <iostream>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iomanip>
#include "base.hpp"
#include "add.hpp"
#include "Div.hpp"
#include "multiply.hpp"
#include "subtract.hpp"
#include "power.hpp"
#include "SevenOpMock.hpp"
#include "FiveOpMock.hpp"
#include "op.hpp"
#include "rand.hpp"

#include "SciOp.hpp"
#include "SciRand.hpp"
#include "SciFactory.hpp"

#include "Precision_factory.hpp"
#include "PrecisionOp.hpp"
#include "PrecisionRand.hpp"

#include "Ceil.hpp"
#include "Floor.hpp"
#include "Abs.hpp"
#include "trunc.hpp"
#include "paren.hpp"

#include "double_factory.hpp"

#include "iterator.hpp"
#include "binary_iterator.hpp"
#include "unary_iterator.hpp"
#include "null_iterator.hpp"
#include "preorder_iterator.hpp"

#include "gtest/gtest.h"

//DELETED PRIOR TESTS

TEST(testDoubleFact, buildOpDoubleFact) {
	double pi = 3.141593;
	DoubleFactory *fact = new DoubleFactory();
	op *op1 = fact->createOp(pi);
	EXPECT_EQ("3.141593", op1->stringify());
}

TEST(testDoubleFact, buildRandDoubleFact) {
	DoubleFactory *fact = new DoubleFactory();
	srand(1);
	Rand *op1 = fact->createRand();

	srand(1);
	double randVal = rand() % 100;
	std::ostringstream obj;
	obj << std::fixed;
	obj << std::setprecision(6);
	obj << randVal;
	std::string objConv = obj.str();	

	EXPECT_EQ(randVal, op1->evaluate());
	EXPECT_EQ(objConv, op1->stringify());
}

TEST(EvaluateDecorator, Ceiling) {
	op* ten_five = new op(10.5);
	op* three_two = new op(3.2);
	add* total = new add(ten_five, three_two);
	
	Ceil* thisCeil = new Ceil(total);
	EXPECT_EQ(14.0, thisCeil->evaluate());
}

TEST(EvaluateDecorator, Floor) {
	op* ten_five = new op(10.5);
	op* three_two = new op(3.2);
	multiply* total = new multiply(ten_five, three_two);
	
	Floor* thisFloor = new Floor(total);
	EXPECT_EQ(33.0, thisFloor->evaluate());
}

TEST(EvaluateDecorator, Absolute) {
	op* ten_five = new op(10.5);
	op* three_two = new op(3.2);
	subtract* total = new subtract(three_two, ten_five);

	Abs* thisAbs = new Abs(total);
	EXPECT_EQ(7.3, thisAbs->evaluate());
}

TEST(EvaluateDecorator, allTogether) {
	op* ten_five = new op(10.5);
	op* three_two = new op(-3.2);
	Div* total = new Div(ten_five, three_two);
	
	Abs* thisAbs = new Abs(total);
	EXPECT_EQ(3.28125, thisAbs->evaluate());
	
	Floor* thisFloor = new Floor(thisAbs);
	EXPECT_EQ(3.0, thisFloor->evaluate());

	Ceil* thisCeiling = new Ceil(thisFloor);
	EXPECT_EQ(3.0, thisCeiling->evaluate());
}
	
TEST(trunc, testTruncObject) {
	add *nyes = new add(new op(7), new op(4));
	Trunc* heyBaws = new Trunc(nyes);
	EXPECT_EQ("11.000000", heyBaws->stringify());
}

TEST(trunc, testTruncObjectWithinObject) {
	add *nyes = new add(new op(7), new op(4));
	Trunc* heyBaws = new Trunc(nyes);
	op *three = new op(3);
	add *argh = new add(heyBaws, three);
	EXPECT_EQ("11.000000 + 3.000000", argh->stringify());
}

TEST(paren, testParenObject) {
	add *nyes = new add(new op(7), new op(4));
	Paren* heyBaws = new Paren(nyes);
	EXPECT_EQ("(7.000000 + 4.000000)", heyBaws->stringify());
}

TEST(paren, testParenObjectWithinObject) {
	add *nyes = new add(new op(7), new op(4));
	Paren* heyBaws = new Paren(nyes);
	op *three = new op(3);
	add *argh = new add(heyBaws, three);
	EXPECT_EQ("(7.000000 + 4.000000) + 3.000000", argh->stringify());
}

TEST(stringifyDec, testStringDecWithDec) {
	add *nyes = new add(new op(7), new op(4));
	Paren* heyBaws = new Paren(nyes);
	op *three = new op(3);
	op *eight = new op(8);
	multiply *nein = new multiply(three, eight);
	Trunc *argh = new Trunc(nein);
	subtract *nyet = new subtract(heyBaws,argh);
	EXPECT_EQ("(7.000000 + 4.000000) - 24.000000", nyet->stringify());
}

//test iterators
TEST(testBinaryIt, testWithOperatorOne) {
	add *nein = new add(new op(7), new op(4));
	Iterator *nyet = nein->create_iterator();
	nyet->first();
	EXPECT_EQ(7, nyet->current()->evaluate());
	nyet->next();
	EXPECT_EQ(4, nyet->current()->evaluate());
	nyet->next();
	EXPECT_EQ(true, nyet->is_done());
}

TEST(testBinaryIt, testWithOperatorTwo) {
	Div *nein = new Div(new op(7), new op(4));
	Iterator *nyet = nein->create_iterator();
	nyet->first();
	EXPECT_EQ(7, nyet->current()->evaluate());
	nyet->next();
	EXPECT_EQ(4, nyet->current()->evaluate());
	nyet->next();
	EXPECT_EQ(true, nyet->is_done());
}

TEST(testUnaryIt, testWithOperatorOne) {
	add *nein = new add(new op(7), new op(4));
	Ceil* non = new Ceil(nein);
	Iterator *nyet = non->create_iterator();
	nyet->first();
	EXPECT_EQ(11, nyet->current()->evaluate());
	nyet->next();
	EXPECT_EQ(true, nyet->is_done());
}

TEST(testUnaryIt, testWithOperatorTwo) {
	multiply* nein = new multiply(new op(7), new op(4));
	Trunc* non = new Trunc(nein);
	Iterator *nyet = non->create_iterator();
	nyet->first();
	EXPECT_EQ(28, nyet->current()->evaluate());
	nyet->next();
	EXPECT_EQ(true, nyet->is_done());
}

TEST(testNullIt, testWithOperatorOne) {
	op* nein = new op(7);
	Iterator *nyet = nein->create_iterator();
	EXPECT_EQ(true, nyet->is_done());
}

//Test preorder
TEST(testPreorderIt, testPreorderItOne) {
	add *nein = new add(new op(6), new op(9));
	add *nyet = new add(nein, new op(18));
	PreorderIterator *newOrder = new PreorderIterator(nyet);
	//std::cout << "yeet3" << std::endl;
	newOrder->first();
	//std::cout << "yeet4" << std::endl;
	EXPECT_EQ(15, newOrder->current()->evaluate());
	newOrder->next();
	EXPECT_EQ(6, newOrder->current()->evaluate());
	newOrder->next();
	EXPECT_EQ(9, newOrder->current()->evaluate());
	newOrder->next();
	EXPECT_EQ(18, newOrder->current()->evaluate());
	newOrder->next();
	EXPECT_EQ(true, newOrder->is_done());
}

TEST(testPreorderIt, testPreorderItTwo) {
	add *nein = new add(new op(6), new op(9));
	Trunc* non = new Trunc(new multiply(new op(6), new op(9)));
	add *nyet = new add(nein, non);
	PreorderIterator *newOrder = new PreorderIterator(nyet);
	//std::cout << "yeet3" << std::endl;
	newOrder->first();
	//std::cout << "yeet4" << std::endl;
	EXPECT_EQ(15, newOrder->current()->evaluate());
	newOrder->next();
	EXPECT_EQ(6, newOrder->current()->evaluate());
	newOrder->next();
	EXPECT_EQ(9, newOrder->current()->evaluate());
	newOrder->next();
	EXPECT_EQ(54, newOrder->current()->evaluate());
	newOrder->next();
	EXPECT_EQ(true, newOrder->is_done());
}

int main(int argc, char **argv) {
        ::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
