#ifndef __OP_HPP__
#define __OP_HPP__

#include "base.hpp"
#include "null_iterator.hpp"
#include <string>

class op : public Base {
    
	private:
		double x;
	public:
        /* Constructors */
        	op(double in) { x = in; };

        /* members Functions */
        	virtual double evaluate() {
			return x;
		}		
        	virtual std::string stringify() {
			return std::to_string(x);
		}
		virtual Base* get_left() {
			return nullptr;
		}
		virtual Base* get_right() {
			return nullptr;
		}

		virtual Iterator* create_iterator() {
			NullIterator* poop = new NullIterator(this);
			return poop;
		}
};

#endif //__OP_HPP__

