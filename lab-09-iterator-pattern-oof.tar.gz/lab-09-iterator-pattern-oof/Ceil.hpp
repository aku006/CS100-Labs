#ifndef __CEIL_HPP__
#define __CEIL_HPP__

#include <iostream>
#include <cmath>
#include "base.hpp"
#include "unary_iterator.hpp"

class Ceil : public Base {
	private:
		Base* target;
	public:
		Ceil(Base* t) {
			target = t;
		}

		virtual double evaluate() {
			return std::ceil(target->evaluate());
		}
	
		virtual std::string stringify() {
			return target->stringify();
		}

		virtual Base* get_left() {
			return target;
		}

		virtual Base* get_right() {
			return nullptr;
		}

		virtual Iterator* create_iterator() {
			UnaryIterator* ceilIterator = new UnaryIterator(this);
			return ceilIterator;
		}
};

#endif
