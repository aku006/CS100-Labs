#ifndef __ITERATOR_HPP__
#define __ITERATOR_HPP__

#include "base.hpp"

class Base;

class Iterator {
	protected:
		Base* self_ptr;
	public:
		Iterator(Base* ptr) {
			this->self_ptr = ptr;
		}
		
		//sets up iterator to start at beginning of traversal
		virtual void first() = 0;
		
		//move onto next element
		virtual void next() = 0;

		//returns if you finished iteratoring thru all elements
		virtual bool is_done() = 0;
		
		//return the element the iterator is currently at
		virtual Base* current() = 0;
};

#endif
