#ifndef __BUBBLE_SORT_HPP__
#define __BUBBLE_SORT_HPP__

#include "sort.hpp"
#include "container.hpp"

class Container;

class BubbleSort : public Sort {
	public:
		BubbleSort() {};

		virtual void sort(Container* container) {
			int i = 0;
			int j = 0;
			
			int n = container->size();
			
			for (i = 0; i < n - 1; i++) {
				for (j = 0; j < n - 1; j++) {
					if (container->at(j)->evaluate() > container->at(j+1)->evaluate()) {
						container->swap(j, j+1);
					}
				}
			}
		}
};

#endif

