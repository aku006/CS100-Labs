#ifndef __ADD_HPP__
#define __ADD_HPP__

#include "base.hpp"

class add : public Base {
	private:
		Base *leftOp;
		Base *rightOp;
	public:
		add(Base *l, Base *r) {
			leftOp = l;
			rightOp = r;
		}

		virtual double evaluate() {
			return (leftOp->evaluate() + rightOp->evaluate());
		}
		virtual std::string stringify() {
			return leftOp->stringify() + " + " + rightOp->stringify();
		}	
};

#endif

