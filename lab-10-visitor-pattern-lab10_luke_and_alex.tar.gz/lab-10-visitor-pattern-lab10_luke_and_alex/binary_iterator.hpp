#ifndef __BINARY_ITERATOR_HPP__
#define __BINARY_ITERATOR_HPP__

#include "iterator.hpp"

class BinaryIterator : public Iterator {
	protected:
		Base* curr;
	public:
		BinaryIterator(Base *ptr): Iterator(ptr) {}
		
		//sets up iterator to start at beginning of traversal
		void first() {
			curr = self_ptr->get_left();
		}
		
		//move onto next element
		void next() {
			if (curr == self_ptr->get_left()) {
				curr = self_ptr->get_right();
			} else {
				curr = nullptr;
			}
		}

		//returns if you finished iteratoring thru all elements
		bool is_done() {
			if( curr == nullptr ) {
				return true;
			}
			return false;
		}
		
		//return the element the iterator is currently at
		Base* current() {
			return curr;
		}
};

#endif
