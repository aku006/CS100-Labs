#ifndef __ABS_HPP__
#define __ABS_HPP__

#include "base_decorator.hpp"

class Abs : public Base_Decorator {
	public:
		Abs(Base* t) : Base_Decorator(t) {}

		virtual double evaluate() {
			return std::abs(target->evaluate());
		}
	
		virtual std::string stringify() {
			return target->stringify();
		}	

		virtual void accept(CountVisitor* v) {
			v->visit_abs();
		}
};

#endif
