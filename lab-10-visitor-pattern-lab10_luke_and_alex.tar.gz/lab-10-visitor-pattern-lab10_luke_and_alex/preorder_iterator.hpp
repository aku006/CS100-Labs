#ifndef __PREORDER_ITERATOR_HPP__
#define __PREORDER_ITERATOR_HPP__

#include <stack>
#include "iterator.hpp"

class PreorderIterator : public Iterator {
	protected:
		//Iterator* curr;
		std::stack<Iterator*> it_stack;
	public:
		PreorderIterator(Base *ptr): Iterator(ptr) {}
		
		//sets up iterator to start at beginning of traversal
		void first() {
			if(!it_stack.empty()) {
				while(!it_stack.empty()) {
					it_stack.pop();
				}
			}
			UnaryIterator* first = new UnaryIterator(self_ptr);
			first->first();
			it_stack.push(first);
			
			//curr = first;
		}
		
		//move onto next element
		void next() {
			Iterator* next = it_stack.top()->current()->create_iterator();
			//std::cout << "yeet1" << std::endl;
			next->first();
			//std::cout << "yeet2" << std::endl;
			it_stack.push(next);
			while( (it_stack.size() > 0) && (it_stack.top()->is_done()) ){
				//std::cout<<"yeet7"<<std::endl;
				//std::cout<<it_stack.top()->current()->evaluate()<<std::endl;
				it_stack.pop();
				if(it_stack.empty()) {
					break;
				}
				//std::cout<<"yeet8"<<std::endl;
				//std::cout<<"stack: "<<it_stack.size()<<std::endl;
				it_stack.top()->next();
				//std::cout<<"yeet9"<<std::endl;
			}
		}

		//returns if you finished iteratoring thru all elements
		bool is_done() {
			if(it_stack.size() == 0) {
				return true;
			}
			return false;
		}
		
		//return the element the iterator is currently at
		Base* current() {
			//std::cout << "yeet5" << std::endl;
			if(!it_stack.empty()) {
				//std::cout<<"yeet6"<<std::endl;
				return it_stack.top()->current();
			} else {
				return nullptr;
			}
		}
};
#endif
