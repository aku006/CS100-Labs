#ifndef __PAREN_HPP_
#define __PAREN_HPP__

#include "base_decorator.hpp"

class Paren : public Base_Decorator {
	public:
		Paren(Base* t) : Base_Decorator(t) {}
		
		virtual double evaluate() {
			return target->evaluate();
		}
		virtual std::string stringify() {
			return "("+target->stringify()+")";
		}

		virtual void accept(CountVisitor* v) {
			v->visit_paren();
		}
};		

#endif
