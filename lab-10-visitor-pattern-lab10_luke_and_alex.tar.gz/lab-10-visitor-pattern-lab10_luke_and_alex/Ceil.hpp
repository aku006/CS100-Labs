#ifndef __CEIL_HPP__
#define __CEIL_HPP__

#include "base_decorator.hpp"

class Ceil : public Base_Decorator {
	public:
		Ceil(Base* t) : Base_Decorator(t) {}

		double evaluate() {
			return std::ceil(target->evaluate());
		}
	
		std::string stringify() {
			return target->stringify();
		}

		void accept(CountVisitor* v) {
			v->visit_ceil();
		}
};

#endif
