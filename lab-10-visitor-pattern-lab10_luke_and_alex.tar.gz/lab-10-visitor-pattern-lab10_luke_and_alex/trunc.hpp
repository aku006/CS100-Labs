#ifndef __TRUNC_HPP_
#define __TRUNC_HPP__

#include "base_decorator.hpp"

class Trunc : public Base_Decorator {
	public:
		Trunc(Base* t) : Base_Decorator(t) {}
		
		virtual double evaluate() {
			return target->evaluate();
		}
		virtual std::string stringify() {
			return std::to_string(target->evaluate());
		}

		virtual void accept(CountVisitor* v) {
			v->visit_trunc();
		}
};		

#endif
