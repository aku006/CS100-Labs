#ifndef __FIVEOPMOCK_HPP__
#define __FIVEOPMOCK_HPP__

#include "base.hpp"
#include "null_iterator.hpp"
#include <iostream>
#include <string>

class FiveOpMock: public Base {
    public:
        FiveOpMock() { };

        virtual double evaluate() { return 5; }
        virtual std::string stringify() { return "5"; }

	virtual Base* get_left() {
		return nullptr;
	}

	virtual Base* get_right() {
		return nullptr;
	}

	virtual Iterator* create_iterator() {
		NullIterator* poop = new NullIterator(this);
		return poop;
	}
};

#endif
