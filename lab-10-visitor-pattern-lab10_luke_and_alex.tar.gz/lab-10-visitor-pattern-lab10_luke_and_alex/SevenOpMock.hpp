#ifndef __SEVENOPMOCK_HPP__
#define __SEVENOPMOCK_HPP__

#include "base.hpp"
#include "null_iterator.hpp"
#include <iostream>
#include <string>

class SevenOpMock: public Base {
    public:
        SevenOpMock() { };

        virtual double evaluate() { return 7.5; }
        virtual std::string stringify() { return "7.5"; }
	virtual Base* get_left() {
		return nullptr;
	}
	virtual Base* get_right() {
		return nullptr;
	}

	virtual Iterator* create_iterator() {
		NullIterator* poop = new NullIterator(this);
		return poop;
	}
};

#endif
