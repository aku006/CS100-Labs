#ifndef __PRECISION_FACTORY_HPP__
#define __PRECISION_FACTORY_HPP__

#include "base_factory.hpp"
#include "PrecisionOp.hpp"
#include "PrecisionRand.hpp"

class PrecisionFactory : public BaseFactory {
    public:
        /* Constructor */
        PrecisionFactory() : BaseFactory() {};

        /*Production Function */
        op* createOp(double value) {
		PrecisionOp *op = new PrecisionOp(value); 
		return op;
	}

        Rand* createRand() {
		PrecisionRand *op = new PrecisionRand();
		return op;
	}
};


#endif //__PRECISION_FACTORY_HPP__
