#ifndef __BASE_DECORATOR_HPP__
#define __BASE_DECORATOR_HPP__

#include "base.hpp"
#include <iostream>
#include <string>
#include <cmath>
#include "unary_iterator.hpp"
#include "visitor.hpp"

class Base_Decorator : public Base {
    protected:
	Base* target;
    public:
        /* Constructors */
        Base_Decorator(Base *t) : target(t) {}

        /* Pure Virtual Functions */
        virtual double evaluate() {
		return target->evaluate();
	}
        virtual std::string stringify() {
		return target->stringify();
	}

	Base* get_left() {
		return target;
	}
	Base* get_right() {
		return nullptr;
	}

	Iterator* create_iterator() {
		UnaryIterator* uIterator = new UnaryIterator(this);
		return uIterator;
	}

	virtual void accept(CountVisitor*) {
		return;
	}
};

#endif
