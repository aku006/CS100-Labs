#ifndef __MULTIPLY_HPP__
#define __MULTIPLY_HPP__

#include "base.hpp"
#include "binary_iterator.hpp"
#include "visitor.hpp"

class multiply : public Base {
        private:
                Base *leftOp;
                Base *rightOp;
        public:
                multiply(Base *l, Base *r) {
                        leftOp = l;
                        rightOp = r;
                }

                virtual double evaluate() {
                        return (leftOp->evaluate() * rightOp->evaluate());
                }
                virtual std::string stringify() {
                        return leftOp->stringify() + " * " + rightOp->stringify();
                }

		virtual Base* get_left() {
			return leftOp;
		}

		virtual Base* get_right() {
			return rightOp;
		}

		virtual Iterator* create_iterator() {
			BinaryIterator* multiplyIterator = new BinaryIterator(this);
			return multiplyIterator;
		}

		virtual void accept(CountVisitor* v) {
			v->visit_mult();
		}
};

#endif

