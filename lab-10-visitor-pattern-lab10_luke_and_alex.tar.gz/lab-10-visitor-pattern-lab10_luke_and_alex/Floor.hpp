#ifndef __FLOOR_HPP__
#define __FLOOR_HPP__

#include "base_decorator.hpp"

class Floor : public Base_Decorator {
	public:
		Floor(Base* t) : Base_Decorator(t) {}

		virtual double evaluate() {
			return std::floor(target->evaluate());
		}
	
		virtual std::string stringify() {
			return target->stringify();
		}

		virtual void accept(CountVisitor* v) {
			v->visit_floor();
		}
};



#endif
