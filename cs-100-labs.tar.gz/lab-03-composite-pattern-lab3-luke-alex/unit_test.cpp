#include <iostream>
#include <cmath>
#include "base.hpp"
#include "add.hpp"
#include "Div.hpp"
#include "multiply.hpp"
#include "subtract.hpp"
#include "power.hpp"
#include "SevenOpMock.hpp"
#include "FiveOpMock.hpp"
#include "gtest/gtest.h"

TEST(testAddOp, testAddEval){
	SevenOpMock *op1 = new SevenOpMock();
	FiveOpMock *op2 = new FiveOpMock();
	add *add12 = new add(op1, op2);
	EXPECT_EQ(12.5, add12->evaluate());
}

TEST(testAddOp, testAddString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        add *add12 = new add(op1, op2);
        EXPECT_EQ("7.5 + 5", add12->stringify());
}

TEST(testDivOp, testDivEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        Div *div12 = new Div(op1, op2);
        EXPECT_EQ(1.5, div12->evaluate());
}

TEST(testDivOp, testDivString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        Div *div12 = new Div(op1, op2);
        EXPECT_EQ("7.5 / 5", div12->stringify());
}

//Multiply test
TEST(testMultiplyOp, testMultiplyEval) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiply37 = new multiply(op1, op2);
        EXPECT_EQ(37.5, multiply37->evaluate());
}

TEST(testMultiplyOp, testMultiplyString) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiply37 = new multiply(op1, op2);
        EXPECT_EQ("7.5 * 5", multiply37->stringify());
}

//Subtract test
TEST(testSubtractOp, testSubtractEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        subtract* subtract2 = new subtract(op1, op2);
        EXPECT_EQ(2.5, subtract2->evaluate());
}

TEST(testSubtractOp, testSubtractString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        subtract* subtract2 = new subtract(op1, op2);
        EXPECT_EQ("7.5 - 5", subtract2->stringify());
}

//Power test
TEST(testPowerOp, testPowerEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        power *power23730 = new power(op1, op2);
        EXPECT_EQ(23730.46875, power23730->evaluate());
}

TEST(testPowerOp, testPowerString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        power *power23730 = new power(op1, op2);
        EXPECT_EQ("7.5 ** 5", power23730->stringify());
}

TEST(testOpWithinOp, testEval) {
	SevenOpMock *op1 = new SevenOpMock();
	FiveOpMock *op2 = new FiveOpMock();
	multiply *multiple = new multiply(op1, op2);
	add *add12 = new add(multiple, op2);
	EXPECT_EQ(42.5, add12->evaluate());
}

TEST(testOpWithinOp, testString) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiple = new multiply(op1, op2);
        add *add12 = new add(multiple, op2);
        EXPECT_EQ("7.5 * 5 + 5", add12->stringify());
}


int main(int argc, char **argv) {
        ::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
