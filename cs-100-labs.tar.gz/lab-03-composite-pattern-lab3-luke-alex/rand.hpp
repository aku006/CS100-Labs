#ifndef __RAND_HPP__
#define __RAND_HPP__

#include <string>
#include <cstdlib>
#include "base.hpp"

class rand : public Base {
	private:
		double x;
	public:
		/*constructors*/
		rand(double in) { x = rand() % 100; };
		
		/*member functions*/
		virtual double evaluate() {
			return x;
		}

		virtual std::string stringify() {
			return std::to_string(x);
		}
};

#endif //__RAND_HPP__

