#ifndef __PRECISION_OP_HPP__
#define __PRECISION_OP_HPP__

#include <sstream>
#include <iomanip>
#include "op.hpp"

class PrecisionOp : public op {
    public:
        /* Constructor */
        PrecisionOp(double in) : op(in) {}

        virtual std::string stringify() {
		std::ostringstream streamObj;
		
		//sets fixed-pt notation
		streamObj << std::fixed;
		//sets precision to two
		streamObj << std::setprecision(2);
		streamObj << this->evaluate();
		
		std::string strObjConv = streamObj.str();
		return strObjConv;
	}
};

#endif //__PRECISION_OP_HPP__
