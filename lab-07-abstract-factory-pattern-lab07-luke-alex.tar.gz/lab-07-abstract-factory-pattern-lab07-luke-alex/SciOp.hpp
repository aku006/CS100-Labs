#ifndef __SCI_OP__
#define __SCI_OP__

#include <sstream>
#include "op.hpp"

class SciOp : public op {
	public:
		SciOp(double in) : op(in) {  }

		virtual std::string stringify() {
			std::ostringstream streamObj;

			streamObj << std::scientific;
			streamObj << this->evaluate();
			std::string strObj = streamObj.str();
			return strObj;
		}
};

#endif
