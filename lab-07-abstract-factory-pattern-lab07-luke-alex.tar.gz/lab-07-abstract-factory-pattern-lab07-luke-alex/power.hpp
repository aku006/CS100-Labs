#ifndef __POWER_HPP__
#define __POWER_HPP__

#include <cmath>
#include "base.hpp"

class power : public Base {
        private:
                Base *leftOp;
                Base *rightOp;
        public:
                power(Base *l, Base *r) {
                        leftOp = l;
                        rightOp = r;
                }

                virtual double evaluate() {
                        return pow(leftOp->evaluate(), rightOp->evaluate());
                }
                virtual std::string stringify() {
                        return leftOp->stringify() + " ** " + rightOp->stringify();
                }
};

#endif
