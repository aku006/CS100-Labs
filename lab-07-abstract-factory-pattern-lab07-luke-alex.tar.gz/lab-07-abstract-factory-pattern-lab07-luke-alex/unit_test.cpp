#include <iostream>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iomanip>
#include "base.hpp"
#include "add.hpp"
#include "Div.hpp"
#include "multiply.hpp"
#include "subtract.hpp"
#include "power.hpp"
#include "SevenOpMock.hpp"
#include "FiveOpMock.hpp"
#include "op.hpp"
#include "rand.hpp"

#include "SciOp.hpp"
#include "SciRand.hpp"
#include "SciFactory.hpp"

#include "Precision_factory.hpp"
#include "PrecisionOp.hpp"
#include "PrecisionRand.hpp"

#include "double_factory.hpp"

#include "gtest/gtest.h"

TEST(testOp, testOpEval) {
	op *op1 = new op(7);
	EXPECT_EQ(7, op1->evaluate());
}

TEST(testAddOp, testAddEval){
	SevenOpMock *op1 = new SevenOpMock();
	FiveOpMock *op2 = new FiveOpMock();
	add *add12 = new add(op1, op2);
	EXPECT_EQ(12.5, add12->evaluate());
}

TEST(testAddOp, testAddString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        add *add12 = new add(op1, op2);
        EXPECT_EQ("7.5 + 5", add12->stringify());
}

TEST(testDivOp, testDivEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        Div *div12 = new Div(op1, op2);
        EXPECT_EQ(1.5, div12->evaluate());
}

TEST(testDivOp, testDivString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        Div *div12 = new Div(op1, op2);
        EXPECT_EQ("7.5 / 5", div12->stringify());
}

//Multiply test
TEST(testMultiplyOp, testMultiplyEval) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiply37 = new multiply(op1, op2);
        EXPECT_EQ(37.5, multiply37->evaluate());
}

TEST(testMultiplyOp, testMultiplyString) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiply37 = new multiply(op1, op2);
        EXPECT_EQ("7.5 * 5", multiply37->stringify());
}

//Subtract test
TEST(testSubtractOp, testSubtractEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        subtract* subtract2 = new subtract(op1, op2);
        EXPECT_EQ(2.5, subtract2->evaluate());
}

TEST(testSubtractOp, testSubtractString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        subtract* subtract2 = new subtract(op1, op2);
        EXPECT_EQ("7.5 - 5", subtract2->stringify());
}

//Power test
TEST(testPowerOp, testPowerEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        power *power23730 = new power(op1, op2);
        EXPECT_EQ(23730.46875, power23730->evaluate());
}

TEST(testPowerOp, testPowerString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        power *power23730 = new power(op1, op2);
        EXPECT_EQ("7.5 ** 5", power23730->stringify());
}

TEST(testOpWithinOp, testEval) {
	SevenOpMock *op1 = new SevenOpMock();
	FiveOpMock *op2 = new FiveOpMock();
	multiply *multiple = new multiply(op1, op2);
	add *add12 = new add(multiple, op2);
	EXPECT_EQ(42.5, add12->evaluate());
}

TEST(testOpWithinOp, testString) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiple = new multiply(op1, op2);
        add *add12 = new add(multiple, op2);
        EXPECT_EQ("7.5 * 5 + 5", add12->stringify());
}

TEST(Scientific, SciOp) {
	double yeet = 12345.6789;
	SciOp* test = new SciOp(yeet);
	EXPECT_EQ("1.234568e+04", test->stringify());
}

TEST(Scientific, SciRand) {
	srand(1);
	SciRand* op = new SciRand();
	std::cout << op->stringify() << std::endl;
	
	srand(1);
	double randVal = rand() % 100;
	std::ostringstream obj;
	obj << std::scientific;
	obj << randVal;
	std::string objConv = obj.str();

	EXPECT_EQ(objConv, op->stringify());
}

TEST(ScientificFactory, SciOp) {
	double value = 12345.6789;
	SciFactory* factory = new SciFactory();
	op* test = factory->createOp(value);
	EXPECT_EQ("1.234568e+04", test->stringify());
}

TEST(ScientificFactory, SciRand) {
	SciFactory* factory = new SciFactory();
	srand(1);
	Rand* test = factory->createRand();

	srand(1);
	double value = rand() % 100;
	std::ostringstream obj;
	obj << std::scientific;
	obj << value;
	std::string objConv = obj.str();

	EXPECT_EQ(value, test->evaluate());
	EXPECT_EQ(objConv, test->stringify());
}

TEST(testPreOp, testPreOpEval){
	double pi = 3.1416;
	PrecisionOp *op1 = new PrecisionOp(pi);
	EXPECT_EQ("3.14", op1->stringify());
}

TEST(testPreRand, testPreRandEval){
	srand(1);
	PrecisionRand *op1 = new PrecisionRand();
	std::cout << op1->stringify() << std::endl;
	srand(1);
	double randVal = rand() % 100;
	std::ostringstream obj;
	obj << std::fixed;
	obj << std::setprecision(2);
	obj << randVal;
	std::string objConv = obj.str();

	EXPECT_EQ(objConv, op1->stringify());
}

TEST(testRand, testRandFunc) {
	srand(1);
	Rand *op1 = new Rand();

	srand(1);
	double randVal = rand() % 100;
	std::ostringstream obj;
	obj << std::fixed;
	obj << std::setprecision(6);
	obj << randVal;
	std::string objConv = obj.str();	

	EXPECT_EQ(randVal, op1->evaluate());
	EXPECT_EQ(objConv, op1->stringify());
}

TEST(testPreFact, buildOpPreFact) {
	double pi = 3.1416;
	PrecisionFactory *fact = new PrecisionFactory();
	op *op1 = fact->createOp(pi);
	EXPECT_EQ("3.14", op1->stringify());
}

TEST(testPreFact, buildRandPreFact) {
	PrecisionFactory *fact = new PrecisionFactory();
	srand(1);
	Rand *op1 = fact->createRand();

	srand(1);
	double randVal = rand() % 100;
	std::ostringstream obj;
	obj << std::fixed;
	obj << std::setprecision(2);
	obj << randVal;
	std::string objConv = obj.str();	

	EXPECT_EQ(randVal, op1->evaluate());
	EXPECT_EQ(objConv, op1->stringify());
}

TEST(testDoubleFact, buildOpDoubleFact) {
	double pi = 3.141593;
	DoubleFactory *fact = new DoubleFactory();
	op *op1 = fact->createOp(pi);
	EXPECT_EQ("3.141593", op1->stringify());
}

TEST(testDoubleFact, buildRandDoubleFact) {
	DoubleFactory *fact = new DoubleFactory();
	srand(1);
	Rand *op1 = fact->createRand();

	srand(1);
	double randVal = rand() % 100;
	std::ostringstream obj;
	obj << std::fixed;
	obj << std::setprecision(6);
	obj << randVal;
	std::string objConv = obj.str();	

	EXPECT_EQ(randVal, op1->evaluate());
	EXPECT_EQ(objConv, op1->stringify());
}

int main(int argc, char **argv) {
        ::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
