#ifndef __FLOOR_HPP__
#define __FLOOR_HPP__

#include <iostream>
#include <cmath>
#include "base.hpp"

class Floor : public Base {
	private:
		Base* target;
	public:
		Floor(Base* t) {
			target = t;
		}

		virtual double evaluate() {
			return std::floor(target->evaluate());
		}
	
		virtual std::string stringify() {
			return target->stringify();
		}
};



#endif
