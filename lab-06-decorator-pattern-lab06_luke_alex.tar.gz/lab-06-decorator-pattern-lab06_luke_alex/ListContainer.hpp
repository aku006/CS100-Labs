#ifndef __LIST_CONTAINER_HPP__
#define __LIST_CONTAINER_HPP__

#include <list>
#include <iterator>
#include "container.hpp"
#include "sort.hpp"

class ListContainer : public Container {
        private:
                std::list<Base*> *myList;
        public:
                ListContainer() {myList = new std::list<Base*>; }
		ListContainer(Sort* function) : Container(function) {myList = new std::list<Base*>; }

                virtual void add_element(Base* element) {
                        myList->push_back(element);
                }

                virtual void print() {
			std::list<Base*>::iterator it;
                        for(it = myList->begin(); it !=  myList->end(); it++) {
                                std::cout << *it << " ";
                        }
                }

                virtual void sort() {
                        if (sort_function != nullptr) {
				sort_function->sort(this);
			}
			else {std::cout << "sort is null" << std::endl; }
                }

                virtual void swap(int i, int j) {
                        Base* temp;
                        std::list<Base*>::iterator it = myList->begin();
			std::list<Base*>::iterator it2 = myList->begin();
                        
			std::advance(it, i);
			std::advance(it2, j);

			temp = *it;
			*it = *it2;
			*it2 = temp;
			
                }

                virtual Base* at(int i) {
                        std::list<Base*>::iterator it = myList->begin();
                        std::advance(it, i);
                        return *it;
                }

                virtual int size() {
                        return myList->size();
                }

};

#endif

