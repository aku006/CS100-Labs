#ifndef __SELECTIONSORT_HPP__
#define __SELECTIONSORT_HPP__

#include "container.hpp"
#include "sort.hpp"

class Container;

class SelectionSort : public Sort {
    public:
        /* Constructors */
        SelectionSort() {};

        /* Pure Virtual Functions */
        virtual void sort(Container* container) {
                //std::cout << "test" << std::endl;
		Base *temp = 0;
                int min;
			
		//std::cout << "test" << std::endl;
                for(int i = 0; i < container->size()-1; ++i) {
                        min = i;

                        for(int j = i+1; j < container->size(); ++j) {
                                if (container->at(j)->evaluate() < container->at(min)->evaluate()) {
                                        min = j;
                                }
                        }

                        container->swap(min, i);
                }
        }
};

#endif //__SORT_HPP__i

