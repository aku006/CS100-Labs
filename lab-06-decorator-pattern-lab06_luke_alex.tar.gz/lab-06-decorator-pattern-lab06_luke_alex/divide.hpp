#ifndef __DIV_HPP__
#define __DIV_HPP__

#include "base.hpp"

class divide : public Base {
	private:
		Base *leftOp;
		Base *rightOp;

	public:
		divide(Base *l, Base *r) {
			leftOp = l;
			rightOp = r;
		}
		
		virtual double evaluate() {
			return (leftOp->evaluate() / rightOp->evaluate());
		}
		virtual std::string stringify() {
			return leftOp->stringify() + " / " + rightOp->stringify();
		}
};

#endif

