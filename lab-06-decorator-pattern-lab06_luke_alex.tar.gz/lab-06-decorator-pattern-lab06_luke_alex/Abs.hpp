#ifndef __ABS_HPP__
#define __ABS_HPP__

#include <iostream>
#include <cmath>
#include "base.hpp"

class Abs : public Base {
	private:
		Base* target;
	public:
		Abs(Base* t) {
			target = t;
		}

		virtual double evaluate() {
			return std::abs(target->evaluate());
		}
	
		virtual std::string stringify() {
			return target->stringify();
		}
};

#endif
