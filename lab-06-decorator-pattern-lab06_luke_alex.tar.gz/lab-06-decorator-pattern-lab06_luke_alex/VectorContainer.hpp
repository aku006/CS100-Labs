#ifndef __VECTORCONTAINER_HPP__
#define __VECTORCONTAINER_HPP__

#include "container.hpp"
#include "sort.hpp"
#include <vector>

class VectorContainer : public Container {
	private:
		std::vector<Base*> *vec;
	public:
		VectorContainer() {vec = new std::vector<Base*>;}
		//VectorContainer(): Container()  { }
		VectorContainer(Sort *func) : Container(func) {vec = new std::vector<Base*>;};
		//VectorContainer(std::vector<Base*> *noob) : vec(noob) {};
		
		virtual void add_element(Base* element) {
			vec->push_back(element);
		}

		virtual void print() {
			for(unsigned i = 0; i < vec->size(); ++i) {
				std::cout << vec->at(i)->stringify() << " ";
			}
		}

		virtual void sort() {
		//	std::cout << "baws" << std::endl;
			if (sort_function != NULL) {
		//		std::cout << "yesss" << std::endl;
				sort_function->sort(this);
				//sort object will call on its corresponding sort function
				//so if sort_function is of selectionsort type, then
				//it will call on the Sort() of selectionsort class
			} else {
				std::cout << "sort  is null" << std::endl;
			}
		} 		
		
		virtual void swap(int i, int j) {
			Base *temp;
			
			for (int x = 0; x < vec->size(); ++x) {
				if (x == i) {
					temp = vec->at(x);
					for(unsigned y = 0; y < vec->size(); ++y) {
						if (y == j) {
							vec->at(x) = vec->at(y);
							vec->at(y) = temp;
							return;
						}
					}
				}
			}
		}

		virtual Base* at(int i) {
			return vec->at(i);
		}

		virtual int size() {
			return vec->size();
		}
};

#endif
