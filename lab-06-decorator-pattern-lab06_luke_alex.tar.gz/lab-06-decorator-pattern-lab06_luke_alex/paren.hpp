#ifndef __PAREN_HPP_
#define __PAREN_HPP__

#include <iostream>
#include <cmath>
#include "base.hpp"


class Paren : public Base {
	private:
		Base* target;
	public:
		Paren(Base* t) {
			target = t;
		}
		
		virtual double evaluate() {
			return target->evaluate();
		}
		virtual std::string stringify() {
			return "("+target->stringify()+")";
		}
};		

#endif
