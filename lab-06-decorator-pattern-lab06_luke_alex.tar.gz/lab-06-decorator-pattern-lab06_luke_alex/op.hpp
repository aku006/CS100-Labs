#ifndef __OP_HPP__
#define __OP_HPP__

#include "base.hpp"
#include <string>

class op : public Base {
    
	private:
		double x;
	public:
        /* Constructors */
        	op(double in) { x = in; };

        /* members Functions */
        	virtual double evaluate() {
			return x;
		}		
        	virtual std::string stringify() {
			return std::to_string(x);
		}
};

#endif //__BASE_HPP__

