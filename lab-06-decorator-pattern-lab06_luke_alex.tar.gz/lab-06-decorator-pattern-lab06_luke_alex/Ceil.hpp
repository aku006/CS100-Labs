#ifndef __CEIL_HPP__
#define __CEIL_HPP__

#include <iostream>
#include <cmath>
#include "base.hpp"

class Ceil : public Base {
	private:
		Base* target;
	public:
		Ceil(Base* t) {
			target = t;
		}

		virtual double evaluate() {
			return std::ceil(target->evaluate());
		}
	
		virtual std::string stringify() {
			return target->stringify();
		}
};

#endif
