#include <iostream>
#include <cmath>
#include "base.hpp"
#include "op.hpp"
#include "add.hpp"
#include "divide.hpp"
#include "multiply.hpp"
#include "subtract.hpp"
#include "power.hpp"
#include "SevenOpMock.hpp"
#include "FiveOpMock.hpp"

#include "container.hpp"
#include "sort.hpp"
#include "VectorContainer.hpp"
#include "SelectionSort.hpp"
#include "ListContainer.hpp"
#include "BubbleSort.hpp"


#include "Ceil.hpp"
#include "Floor.hpp"
#include "Abs.hpp"
#include "trunc.hpp"
#include "paren.hpp"

#include "gtest/gtest.h"

TEST(testAddOp, testAddEval){
	SevenOpMock *op1 = new SevenOpMock();
	FiveOpMock *op2 = new FiveOpMock();
	add *add12 = new add(op1, op2);
	EXPECT_EQ(12.5, add12->evaluate());
}

TEST(testAddOp, testAddString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        add *add12 = new add(op1, op2);
        EXPECT_EQ("7.5 + 5", add12->stringify());
}

TEST(testDivOp, testDivEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        divide *div12 = new divide(op1, op2);
        EXPECT_EQ(1.5, div12->evaluate());
}

TEST(testDivOp, testDivString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        divide *div12 = new divide(op1, op2);
        EXPECT_EQ("7.5 / 5", div12->stringify());
}

TEST(testMultiplyOp, testMultiplyEval) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiply37 = new multiply(op1, op2);
        EXPECT_EQ(37.5, multiply37->evaluate());
}

TEST(testMultiplyOp, testMultiplyString) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiply37 = new multiply(op1, op2);
        EXPECT_EQ("7.5 * 5", multiply37->stringify());
}

TEST(testSubtractOp, testSubtractEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        subtract* subtract2 = new subtract(op1, op2);
        EXPECT_EQ(2.5, subtract2->evaluate());
}

TEST(testSubtractOp, testSubtractString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        subtract* subtract2 = new subtract(op1, op2);
        EXPECT_EQ("7.5 - 5", subtract2->stringify());
}

TEST(testPowerOp, testPowerEval){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        power *power23730 = new power(op1, op2);
        EXPECT_EQ(23730.46875, power23730->evaluate());
}

TEST(testPowerOp, testPowerString){
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        power *power23730 = new power(op1, op2);
        EXPECT_EQ("7.5 ** 5", power23730->stringify());
}

TEST(testOpWithinOp, testEval) {
	SevenOpMock *op1 = new SevenOpMock();
	FiveOpMock *op2 = new FiveOpMock();
	multiply *multiple = new multiply(op1, op2);
	add *add12 = new add(multiple, op2);
	EXPECT_EQ(42.5, add12->evaluate());
}

TEST(testOpWithinOp, testString) {
        SevenOpMock *op1 = new SevenOpMock();
        FiveOpMock *op2 = new FiveOpMock();
        multiply *multiple = new multiply(op1, op2);
        add *add12 = new add(multiple, op2);
        EXPECT_EQ("7.5 * 5 + 5", add12->stringify());
}

TEST(testOp, testOpEval) {
	op *five = new op(5);
	EXPECT_EQ(5, five->evaluate());
}

TEST(testOp, testOpString) {
	op *five = new op(5);
	EXPECT_EQ("5.000000", five->stringify());
}

TEST(testTree, testTreeStringify) {
	op *three = new op(3);
	op *sev = new op(7);
	op *four = new op(4);
	op *two = new op(2);

	add *add37 = new add(three, sev);
	subtract *sub42 = new subtract(four, two);
	multiply *mult = new multiply(add37, sub42);

	EXPECT_EQ("3.000000 + 7.000000 * 4.000000 - 2.000000", mult->stringify());
}

TEST(testTree, testTreeEval) {
        op *three = new op(3);
        op *sev = new op(7);
        op *four = new op(4);
        op *two = new op(2);

        add *add37 = new add(three, sev);
        subtract *sub42 = new subtract(four, two);
        multiply *mult = new multiply(add37, sub42);

        EXPECT_EQ(20, mult->evaluate());
}

//initial test given on readme
TEST(VectorContainerTestSet, SizeTest) {
	op *seven = new op(7);
	op *five = new op(5);
	VectorContainer *test_container = new VectorContainer();

	test_container->add_element(seven);
	test_container->add_element(five);
	
	EXPECT_EQ(test_container->size(), 2);
	//EXPECT_EQ(test_container->at(0)->evaluate(), 7);
}

TEST(VectorContainerTestSet, EvalTest) {
        op *seven = new op(7);
	//op *five = new op(5);
        VectorContainer *test_container = new VectorContainer();

        test_container->add_element(seven);

        //EXPECT_EQ(test_container->size(), 1);
        EXPECT_EQ(test_container->at(0)->evaluate(), 7);
}

TEST(VectorContainerTestSet, SwapTest) {
        op *seven = new op(7);
	op *five = new op(5);
        VectorContainer *test_container = new VectorContainer();

        test_container->add_element(seven);
	test_container->add_element(five);
	
	test_container->swap(0,1);
	test_container->print();
	EXPECT_EQ(test_container->at(0)->evaluate(), 5);
	EXPECT_EQ(test_container->at(1)->evaluate(), 7);
}

TEST(VectorSort, VecSelect) {
        op *seven = new op(7);
        op *five = new op(5);

	SelectionSort *sorted = new SelectionSort();

        VectorContainer *test_container = new VectorContainer(sorted);
	test_container->add_element(seven);

        test_container->add_element(five);
	test_container->sort();

        EXPECT_EQ(test_container->at(0)->evaluate(), 5);
        EXPECT_EQ(test_container->at(1)->evaluate(), 7);
}

TEST(VectorSort, VecBubble) {
        op *seven = new op(7);
        op *four = new op(4);
        multiply *TreeA = new multiply(seven, four);

        op *three = new op(3);
        op *two = new op(2);
        add *TreeB = new add(three, two);

        op *ten = new op(10);
        op *six = new op(6);
        subtract *TreeC = new subtract(ten, six);

        BubbleSort *sortThis = new BubbleSort();
        VectorContainer *test_container = new VectorContainer(sortThis);

        test_container->add_element(TreeA);
        test_container->add_element(TreeB);
        test_container->add_element(TreeC);
        test_container->sort();

        ASSERT_EQ(test_container->size(), 3);
        EXPECT_EQ(test_container->at(0)->evaluate(), 4);
        EXPECT_EQ(test_container->at(1)->evaluate(), 5);
        EXPECT_EQ(test_container->at(2)->evaluate(), 28);
}	

//List test
TEST(ListContainerTestSet, SizeTest) {
	op *seven = new op(7);
	ListContainer *list_container = new ListContainer();

	list_container->add_element(seven);

	EXPECT_EQ(list_container->size(), 1);
}

TEST(ListContainerTestSet, EvalTest) {
	op *seven = new op(7);
	ListContainer *list_container = new ListContainer();

	list_container->add_element(seven);
	EXPECT_EQ(list_container->at(0)->evaluate(), 7);
}

TEST(ListContainerTestSet, SwapTest) {
	op *seven = new op(7);
	op *five = new op(5);
	ListContainer *list_container = new ListContainer();

	list_container->add_element(seven);
	list_container->add_element(five);

	list_container->swap(0,1);
	list_container->print();
	EXPECT_EQ(list_container->at(0)->evaluate(), 5);
	EXPECT_EQ(list_container->at(1)->evaluate(), 7);
}

TEST(ListSort, BubbleSortTest) {
	op *seven = new op(7);
	op *four = new op(4);
	multiply *TreeA = new multiply(seven, four);

	op *three = new op(3);
	op *two = new op(2);
	add *TreeB = new add(three, two);

	op *ten = new op(10);
	op *six = new op(6);
	subtract *TreeC = new subtract(ten, six);

	BubbleSort *sortThis = new BubbleSort();
	ListContainer *list = new ListContainer(sortThis);

	list->add_element(TreeA);
	list->add_element(TreeB);
	list->add_element(TreeC);
	list->sort();
	
	ASSERT_EQ(list->size(), 3);
	EXPECT_EQ(list->at(0)->evaluate(), 4);
	EXPECT_EQ(list->at(1)->evaluate(), 5);
	EXPECT_EQ(list->at(2)->evaluate(), 28);
}

TEST(ListSort, SelectionSortTest) {
        op *seven = new op(7);
        op *four = new op(4);
        multiply *TreeA = new multiply(seven, four);

        op *three = new op(3);
        op *two = new op(2);
        add *TreeB = new add(three, two);

        op *ten = new op(10);
        op *six = new op(6);
        subtract *TreeC = new subtract(ten, six);

        SelectionSort *sortThis = new SelectionSort();
        ListContainer *list = new ListContainer(sortThis);

        list->add_element(TreeA);
        list->add_element(TreeB);
        list->add_element(TreeC);
        list->sort();

        ASSERT_EQ(list->size(), 3);
        EXPECT_EQ(list->at(0)->evaluate(), 4);
        EXPECT_EQ(list->at(1)->evaluate(), 5);
        EXPECT_EQ(list->at(2)->evaluate(), 28);
}

TEST(EvaluateDecorator, Ceiling) {
	op* ten_five = new op(10.5);
	op* three_two = new op(3.2);
	add* total = new add(ten_five, three_two);
	
	Ceil* thisCeil = new Ceil(total);
	EXPECT_EQ(14.0, thisCeil->evaluate());
}

TEST(EvaluateDecorator, Floor) {
	op* ten_five = new op(10.5);
	op* three_two = new op(3.2);
	multiply* total = new multiply(ten_five, three_two);
	
	Floor* thisFloor = new Floor(total);
	EXPECT_EQ(33.0, thisFloor->evaluate());
}

TEST(EvaluateDecorator, Absolute) {
	op* ten_five = new op(10.5);
	op* three_two = new op(3.2);
	subtract* total = new subtract(three_two, ten_five);

	Abs* thisAbs = new Abs(total);
	EXPECT_EQ(7.3, thisAbs->evaluate());
}

TEST(EvaluateDecorator, allTogether) {
	op* ten_five = new op(10.5);
	op* three_two = new op(-3.2);
	divide* total = new divide(ten_five, three_two);
	
	Abs* thisAbs = new Abs(total);
	EXPECT_EQ(3.28125, thisAbs->evaluate());
	
	Floor* thisFloor = new Floor(thisAbs);
	EXPECT_EQ(3.0, thisFloor->evaluate());

	Ceil* thisCeiling = new Ceil(thisFloor);
	EXPECT_EQ(3.0, thisCeiling->evaluate());
}
	
TEST(trunc, testTruncObject) {
	add *nyes = new add(new op(7), new op(4));
	Trunc* heyBaws = new Trunc(nyes);
	EXPECT_EQ("11.000000", heyBaws->stringify());
}

TEST(trunc, testTruncObjectWithinObject) {
	add *nyes = new add(new op(7), new op(4));
	Trunc* heyBaws = new Trunc(nyes);
	op *three = new op(3);
	add *argh = new add(heyBaws, three);
	EXPECT_EQ("11.000000 + 3.000000", argh->stringify());
}

TEST(paren, testParenObject) {
	add *nyes = new add(new op(7), new op(4));
	Paren* heyBaws = new Paren(nyes);
	EXPECT_EQ("(7.000000 + 4.000000)", heyBaws->stringify());
}

TEST(paren, testParenObjectWithinObject) {
	add *nyes = new add(new op(7), new op(4));
	Paren* heyBaws = new Paren(nyes);
	op *three = new op(3);
	add *argh = new add(heyBaws, three);
	EXPECT_EQ("(7.000000 + 4.000000) + 3.000000", argh->stringify());
}

int main(int argc, char **argv) {
        ::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}

